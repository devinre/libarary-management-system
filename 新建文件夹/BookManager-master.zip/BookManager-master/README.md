BookManager
===========

Qt and SQLite based book manager.

简易图书管理系统，数据库使用技术上机作业。

---

设计与演示，请参加：

基于Qt和Sqlite的跨平台的图书管理系统的设计与实现 - MilkCu博客  
<http://www.milkcu.com/blog/archives/qt-and-sqlite-based-book-manager.html>
