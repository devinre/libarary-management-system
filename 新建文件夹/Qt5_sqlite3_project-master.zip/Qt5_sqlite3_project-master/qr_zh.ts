<!DOCTYPE TS><TS>
<context>
    <name>EditRecordDlg</name>
    <message>
        <source>Edit a record</source>
        <translation type="unfinished">编辑记录</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="unfinished">编号:</translation>
    </message>
    <message>
        <source>name:</source>
        <translation type="unfinished">名称:</translation>
    </message>
    <message>
        <source>producer:</source>
        <translation type="unfinished">厂家:</translation>
    </message>
    <message>
        <source>price:</source>
        <translation type="unfinished">价格:</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished">确定</translation>
    </message>
    <message>
        <source>Cancle</source>
        <translation type="unfinished">取消</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <source>Database Management</source>
        <translation type="obsolete">数据库管理系统</translation>
    </message>
    <message>
        <source>import records</source>
        <translation type="unfinished">入库单</translation>
    </message>
    <message>
        <source>export records</source>
        <translation type="unfinished">出库单</translation>
    </message>
    <message>
        <source>storage</source>
        <translation type="unfinished">库存</translation>
    </message>
    <message>
        <source>ID</source>
        <translation type="unfinished">编号</translation>
    </message>
    <message>
        <source>name</source>
        <translation type="unfinished">名称</translation>
    </message>
    <message>
        <source>producer</source>
        <translation type="unfinished">厂商</translation>
    </message>
    <message>
        <source>price</source>
        <translation type="unfinished">价格</translation>
    </message>
    <message>
        <source>Database Management System</source>
        <translation type="unfinished">数据库管理系统</translation>
    </message>
    <message>
        <source>refresh storage</source>
        <translation type="unfinished">更新库存</translation>
    </message>
    <message>
        <source>=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>order by:</source>
        <translation type="unfinished">排序:</translation>
    </message>
    <message>
        <source>and</source>
        <translation type="unfinished">且</translation>
    </message>
    <message>
        <source>or</source>
        <translation type="unfinished">或</translation>
    </message>
    <message>
        <source>increase</source>
        <translation type="unfinished">升序</translation>
    </message>
    <message>
        <source>descend</source>
        <translation type="unfinished">降序</translation>
    </message>
    <message>
        <source>query</source>
        <translation type="unfinished">查询</translation>
    </message>
    <message>
        <source>table</source>
        <translation type="unfinished">表单</translation>
    </message>
    <message>
        <source>filter query</source>
        <translation type="unfinished">过滤查询</translation>
    </message>
    <message>
        <source>close</source>
        <translation type="unfinished">关闭</translation>
    </message>
    <message>
        <source>operate</source>
        <translation type="unfinished">表单操作</translation>
    </message>
    <message>
        <source>add</source>
        <translation type="unfinished">增加记录</translation>
    </message>
    <message>
        <source>delete</source>
        <translation type="unfinished">删除记录</translation>
    </message>
    <message>
        <source>modify</source>
        <translation type="unfinished">修改记录</translation>
    </message>
</context>
<context>
    <name>MainForm</name>
    <message>
        <source>Database Management System Based on QR Code</source>
        <translation type="unfinished">基于QR码的进出库管理系统</translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="unfinished">编号:</translation>
    </message>
    <message>
        <source>name:</source>
        <translation type="unfinished">名称:</translation>
    </message>
    <message>
        <source>producer:</source>
        <translation type="unfinished">厂商:</translation>
    </message>
    <message>
        <source>price:</source>
        <translation type="unfinished">价格:</translation>
    </message>
    <message>
        <source>QRCode detected! Save, Close or Cancel?</source>
        <translation type="unfinished">扫描到QR码!保存,停止扫描,还是取消?</translation>
    </message>
    <message>
        <source>Object detected</source>
        <translation type="unfinished">检测到的物品</translation>
    </message>
    <message>
        <source>Import</source>
        <translation type="obsolete">入库</translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="obsolete">出库</translation>
    </message>
    <message>
        <source>Magement System</source>
        <translation type="unfinished">库存管理</translation>
    </message>
    <message>
        <source>import</source>
        <translation type="unfinished">入库</translation>
    </message>
    <message>
        <source>export</source>
        <translation type="unfinished">出库</translation>
    </message>
</context>
<context>
    <name>ManagementForm</name>
    <message>
        <source>Do you want to delete the current record?</source>
        <translation type="unfinished">确定要删除当前记录?</translation>
    </message>
</context>
</TS>
