﻿#ifndef CONFIGURE_CPP
#define CONFIGURE_CPP

#include "configure.h"

namespace Configure {

    const char* DATA_PATH = ".\\Data\\";

}

#endif // CONFIGURE_CPP
