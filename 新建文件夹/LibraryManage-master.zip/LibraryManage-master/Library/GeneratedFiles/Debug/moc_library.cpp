/****************************************************************************
** Meta object code from reading C++ file 'library.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../library.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'library.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Library_t {
    QByteArrayData data[25];
    char stringdata0[263];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Library_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Library_t qt_meta_stringdata_Library = {
    {
QT_MOC_LITERAL(0, 0, 7), // "Library"
QT_MOC_LITERAL(1, 8, 10), // "updatetime"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 10), // "setwindow4"
QT_MOC_LITERAL(4, 31, 10), // "setwindow5"
QT_MOC_LITERAL(5, 42, 11), // "setwindow01"
QT_MOC_LITERAL(6, 54, 11), // "setwindow02"
QT_MOC_LITERAL(7, 66, 12), // "setbutton011"
QT_MOC_LITERAL(8, 79, 11), // "setbutton21"
QT_MOC_LITERAL(9, 91, 11), // "setbutton72"
QT_MOC_LITERAL(10, 103, 11), // "setbutton83"
QT_MOC_LITERAL(11, 115, 11), // "setbutton92"
QT_MOC_LITERAL(12, 127, 6), // "Query1"
QT_MOC_LITERAL(13, 134, 10), // "QueryTree1"
QT_MOC_LITERAL(14, 145, 16), // "QTreeWidgetItem*"
QT_MOC_LITERAL(15, 162, 8), // "AddBook7"
QT_MOC_LITERAL(16, 171, 8), // "AddUser5"
QT_MOC_LITERAL(17, 180, 5), // "Logon"
QT_MOC_LITERAL(18, 186, 9), // "Logon_out"
QT_MOC_LITERAL(19, 196, 11), // "Borrow_Book"
QT_MOC_LITERAL(20, 208, 11), // "Return_Book"
QT_MOC_LITERAL(21, 220, 11), // "DeleteUser3"
QT_MOC_LITERAL(22, 232, 8), // "OpenFile"
QT_MOC_LITERAL(23, 241, 12), // "DeleteBook01"
QT_MOC_LITERAL(24, 254, 8) // "AddBook8"

    },
    "Library\0updatetime\0\0setwindow4\0"
    "setwindow5\0setwindow01\0setwindow02\0"
    "setbutton011\0setbutton21\0setbutton72\0"
    "setbutton83\0setbutton92\0Query1\0"
    "QueryTree1\0QTreeWidgetItem*\0AddBook7\0"
    "AddUser5\0Logon\0Logon_out\0Borrow_Book\0"
    "Return_Book\0DeleteUser3\0OpenFile\0"
    "DeleteBook01\0AddBook8"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Library[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x08 /* Private */,
       3,    0,  125,    2, 0x08 /* Private */,
       4,    0,  126,    2, 0x08 /* Private */,
       5,    0,  127,    2, 0x08 /* Private */,
       6,    0,  128,    2, 0x08 /* Private */,
       7,    0,  129,    2, 0x08 /* Private */,
       8,    0,  130,    2, 0x08 /* Private */,
       9,    0,  131,    2, 0x08 /* Private */,
      10,    0,  132,    2, 0x08 /* Private */,
      11,    0,  133,    2, 0x08 /* Private */,
      12,    0,  134,    2, 0x08 /* Private */,
      13,    2,  135,    2, 0x08 /* Private */,
      15,    0,  140,    2, 0x08 /* Private */,
      16,    0,  141,    2, 0x08 /* Private */,
      17,    0,  142,    2, 0x08 /* Private */,
      18,    0,  143,    2, 0x08 /* Private */,
      19,    0,  144,    2, 0x08 /* Private */,
      20,    0,  145,    2, 0x08 /* Private */,
      21,    0,  146,    2, 0x08 /* Private */,
      22,    0,  147,    2, 0x08 /* Private */,
      23,    0,  148,    2, 0x08 /* Private */,
      24,    0,  149,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 14, QMetaType::Int,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Library::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Library *_t = static_cast<Library *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updatetime(); break;
        case 1: _t->setwindow4(); break;
        case 2: _t->setwindow5(); break;
        case 3: _t->setwindow01(); break;
        case 4: _t->setwindow02(); break;
        case 5: _t->setbutton011(); break;
        case 6: _t->setbutton21(); break;
        case 7: _t->setbutton72(); break;
        case 8: _t->setbutton83(); break;
        case 9: _t->setbutton92(); break;
        case 10: _t->Query1(); break;
        case 11: _t->QueryTree1((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 12: _t->AddBook7(); break;
        case 13: _t->AddUser5(); break;
        case 14: _t->Logon(); break;
        case 15: _t->Logon_out(); break;
        case 16: _t->Borrow_Book(); break;
        case 17: _t->Return_Book(); break;
        case 18: _t->DeleteUser3(); break;
        case 19: _t->OpenFile(); break;
        case 20: _t->DeleteBook01(); break;
        case 21: _t->AddBook8(); break;
        default: ;
        }
    }
}

const QMetaObject Library::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Library.data,
      qt_meta_data_Library,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Library::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Library::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Library.stringdata0))
        return static_cast<void*>(const_cast< Library*>(this));
    return QObject::qt_metacast(_clname);
}

int Library::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
