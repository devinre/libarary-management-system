<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>BookDialog</name>
    <message>
        <location filename="BookDialog.cpp" line="28"/>
        <source>Warning</source>
        <translatorcomment>警告</translatorcomment>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="BookDialog.cpp" line="28"/>
        <source>Input information incompletely!</source>
        <translation>请输入完整的信息！</translation>
    </message>
</context>
<context>
    <name>BookDialogClass</name>
    <message>
        <location filename="BookDialog.ui" line="26"/>
        <source>BookDialog</source>
        <translation>书籍管理</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="45"/>
        <source>&amp;OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Author:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">作者：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Type:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">图书类型：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Press:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">出版社：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;PublishDate:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">出版日期：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="100"/>
        <source>yyyy-MM-dd</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;PageNum:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">页数：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Price:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">价格：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;ID:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">书籍编号：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Name:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">书籍名字：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;LendTimes:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">借出次数：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="183"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Status:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">书籍状态：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="52"/>
        <source>Author:</source>
        <translation>作    者：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="69"/>
        <source>Type:</source>
        <translation>书籍类别：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="76"/>
        <source>Press:</source>
        <translation>出 版 社：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="93"/>
        <source>PublishDate:</source>
        <translation>出版日期：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="116"/>
        <source>PageNum</source>
        <translation>页    数：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="136"/>
        <source>Price:</source>
        <translation>书籍价格：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="159"/>
        <source>*BookID:</source>
        <translation>书籍编号：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="166"/>
        <source>*BookName:</source>
        <translation>书籍名字：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="173"/>
        <source>LendTimes:</source>
        <translation>借出次数：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="193"/>
        <source>Status:</source>
        <translation>当前状态：</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="201"/>
        <source>InLibrary</source>
        <translation>在馆</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="206"/>
        <source>LendOut</source>
        <translation>借出</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="211"/>
        <source>Lost</source>
        <translation>遗失</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="219"/>
        <source>&amp;Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="BookDialog.ui" line="226"/>
        <source>&amp;Clear</source>
        <translation>清空</translation>
    </message>
</context>
<context>
    <name>BookLogManage</name>
    <message>
        <location filename="BookLogManage.cpp" line="23"/>
        <location filename="BookLogManage.cpp" line="77"/>
        <location filename="BookLogManage.cpp" line="82"/>
        <source>Result</source>
        <translation>结果</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="24"/>
        <source>Operator</source>
        <translation>操作员</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="25"/>
        <source>BookID</source>
        <translation>书籍编号</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="26"/>
        <source>BookName</source>
        <translation>书籍名字</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="27"/>
        <source>Operation</source>
        <translation>操作</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="28"/>
        <source>IP</source>
        <translation>操作员IP</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="29"/>
        <source>Type</source>
        <translation>书籍类型</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="30"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="31"/>
        <source>DateTime</source>
        <translation>操作日期</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="59"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="60"/>
        <source>Ensure delete book log?</source>
        <translation>确定删除书籍日志？</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="77"/>
        <source>Delete book log successfully!</source>
        <translation>删除书籍日志成功！</translation>
    </message>
    <message>
        <location filename="BookLogManage.cpp" line="82"/>
        <source>Delete book log failed!
</source>
        <translation>删除书籍日志失败！</translation>
    </message>
</context>
<context>
    <name>BookLogManageClass</name>
    <message>
        <source>MainWindow</source>
        <translation type="obsolete">书籍日志管理</translation>
    </message>
    <message>
        <location filename="BookLogManage.ui" line="14"/>
        <source>BookLogManage</source>
        <translation>书籍日志管理</translation>
    </message>
    <message>
        <location filename="BookLogManage.ui" line="30"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="BookLogManage.ui" line="45"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="BookLogManage.ui" line="50"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="BookLogManage.ui" line="55"/>
        <source>Search</source>
        <translation>查找</translation>
    </message>
    <message>
        <location filename="BookLogManage.ui" line="60"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
</context>
<context>
    <name>BookManage</name>
    <message>
        <location filename="bookmanage.cpp" line="52"/>
        <source>Status</source>
        <translation>书籍状态</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="53"/>
        <source>ID</source>
        <translation>书籍编号</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="54"/>
        <source>BookName</source>
        <translation>书籍名字</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="55"/>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="56"/>
        <source>Type</source>
        <translation>书籍类型</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="57"/>
        <source>Press</source>
        <translation>出版社</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="58"/>
        <source>PublishDate</source>
        <translation>出版日期</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="59"/>
        <source>PageNum</source>
        <translation>页数</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="60"/>
        <source>Price</source>
        <translation>书籍价格</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="61"/>
        <source>AddTime</source>
        <translation>入库时间</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="62"/>
        <source>LendTimes</source>
        <translation>借出次数</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="67"/>
        <source>AddBook</source>
        <translation>添加书籍</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="81"/>
        <location filename="bookmanage.cpp" line="110"/>
        <source>Result</source>
        <translation>结果</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="82"/>
        <source>Continue?</source>
        <translation>继续？</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="160"/>
        <location filename="bookmanage.cpp" line="181"/>
        <location filename="bookmanage.cpp" line="269"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="160"/>
        <location filename="bookmanage.cpp" line="181"/>
        <location filename="bookmanage.cpp" line="269"/>
        <source>Select a book!</source>
        <translation>请选择一本书！</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="167"/>
        <source>Delete Book</source>
        <translation>删除书籍</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="167"/>
        <source>Delete &lt;&lt;</source>
        <translation>删除《</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="168"/>
        <source>&gt;&gt;?</source>
        <translation>》？</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="185"/>
        <source>UpdateBook</source>
        <translation>更新书籍</translation>
    </message>
    <message>
        <location filename="bookmanage.cpp" line="262"/>
        <source>ReaderInformation</source>
        <translation>读者信息</translation>
    </message>
</context>
<context>
    <name>BookManageClass</name>
    <message>
        <source>MainWindow</source>
        <translation type="obsolete">书籍管理</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="14"/>
        <source>BookManage</source>
        <translation>书籍管理</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="27"/>
        <source>BookID:</source>
        <translation>书籍编号：</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="50"/>
        <source>BookNmae:</source>
        <translation>书籍名字：</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="73"/>
        <source>BookType:</source>
        <translation>书籍类型：</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="102"/>
        <source>Search</source>
        <translation>查找</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="150"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="167"/>
        <source>AddBook</source>
        <translation>添加书籍</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="172"/>
        <source>DelBook</source>
        <translation>删除书籍</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="177"/>
        <source>UpdateBook</source>
        <translation>更新书籍</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="182"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="187"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="192"/>
        <source>QueryBook</source>
        <translation>查询书籍</translation>
    </message>
    <message>
        <location filename="bookmanage.ui" line="197"/>
        <source>LendOut</source>
        <translation>借出书籍</translation>
    </message>
</context>
<context>
    <name>BookSystem</name>
    <message>
        <location filename="booksystem.cpp" line="232"/>
        <source>UpdatePassword</source>
        <translation>修改密码</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="233"/>
        <source>You hav&apos;t log on!</source>
        <translation>请先登录！</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="250"/>
        <source>ShowGPS</source>
        <translation>显示导航</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="257"/>
        <source>CloseGPS</source>
        <translation>关闭导航</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="266"/>
        <location filename="booksystem.cpp" line="325"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="266"/>
        <location filename="booksystem.cpp" line="325"/>
        <source>Are you sure to quit book system?</source>
        <translation>确定退出图书管理系统？</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="298"/>
        <source>Logon</source>
        <translation>登录</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="298"/>
        <source>You have log on!</source>
        <translation>已经登录！</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="341"/>
        <location filename="booksystem.cpp" line="345"/>
        <source>Logout</source>
        <translation>注销</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="341"/>
        <source>Logout successfully!</source>
        <translation>注销成功</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="345"/>
        <source>You have&apos;t log on!</source>
        <translation>请先登录！</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="350"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="booksystem.cpp" line="350"/>
        <source>BookSystem V1.0Maker:jiangxiaotao2010.1</source>
        <translation>图书管理系统V1.0

     制 作 人：江孝涛
      
     制作时间：2010年1月
</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="obsolete">关于本应用程序</translation>
    </message>
</context>
<context>
    <name>BookSystemClass</name>
    <message>
        <location filename="booksystem.ui" line="26"/>
        <source>BookSystem</source>
        <translation>图书管理系统V1.0</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="103"/>
        <source>GernelOperation</source>
        <translation>常规操作</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="133"/>
        <source>LendBook</source>
        <translation>借出书籍</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="186"/>
        <source>ReturnBook</source>
        <translation>归还书籍</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="224"/>
        <location filename="booksystem.ui" line="992"/>
        <source>QueryBook</source>
        <translation>查找书籍</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="262"/>
        <source>renewal</source>
        <translation>续借书籍</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="294"/>
        <location filename="booksystem.ui" line="799"/>
        <source>DataManage</source>
        <translation>数据管理</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="318"/>
        <location filename="booksystem.ui" line="819"/>
        <source>BookManage</source>
        <translation>书籍管理</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="356"/>
        <location filename="booksystem.ui" line="803"/>
        <source>ReaderManage</source>
        <translation>读者管理</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="394"/>
        <location filename="booksystem.ui" line="812"/>
        <source>LogManage</source>
        <translation>日志管理</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="426"/>
        <source>Statistic</source>
        <translation>统计</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="447"/>
        <location filename="booksystem.ui" line="997"/>
        <source>LendRecord</source>
        <translation>借出记录</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="485"/>
        <location filename="booksystem.ui" line="1026"/>
        <source>UserTable</source>
        <translation>用户列表</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="523"/>
        <source>BookStat</source>
        <translation>书籍统计</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="561"/>
        <source>OverDueRec</source>
        <translation>逾期记录</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="593"/>
        <source>SystemSet</source>
        <translation>系统设置</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="617"/>
        <location filename="booksystem.ui" line="889"/>
        <location filename="booksystem.ui" line="892"/>
        <source>Logon</source>
        <translation>登录</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="655"/>
        <source>UserManage</source>
        <translation>用户管理</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="693"/>
        <source>LogOut</source>
        <translation>注销</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="731"/>
        <location filename="booksystem.ui" line="901"/>
        <source>PwdModify</source>
        <translation>修改密码</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="778"/>
        <source>Manager</source>
        <translation>系统管理</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="782"/>
        <source>User Manage</source>
        <translation>用户管理</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="832"/>
        <source>Lend/Return</source>
        <translation>借出/归还</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="836"/>
        <source>Query/Statistics</source>
        <translation>查询/统计</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="852"/>
        <source>&amp;Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="872"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="910"/>
        <source>Logout</source>
        <translation>注销</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="919"/>
        <source>&amp;Exit</source>
        <translation>退出系统</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="928"/>
        <source>AddUser</source>
        <translation>添加用户</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="937"/>
        <source>DelUser</source>
        <translation>删除用户</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="942"/>
        <source>UpdateUser</source>
        <translation>更新用户</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="951"/>
        <source>AddBook</source>
        <translation>添加书籍</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="960"/>
        <source>DeleteBook</source>
        <translation>删除书籍</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="969"/>
        <source>Lend</source>
        <translation>借出书籍</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="978"/>
        <source>Return</source>
        <translation>归还书籍</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="983"/>
        <source>Renewal</source>
        <translation>续借书籍</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1002"/>
        <source>LendStatistics</source>
        <translation>借出统计</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1007"/>
        <source>Overdue record</source>
        <translation>逾期记录</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1016"/>
        <source>HelpDocument</source>
        <translation>帮助文档</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1021"/>
        <source>&amp;About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1035"/>
        <source>BookTable</source>
        <translation>书籍列表</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1044"/>
        <source>CloseGPS</source>
        <translation>关闭导航</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1049"/>
        <source>AddReader</source>
        <translation>添加读者</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1054"/>
        <source>DelReader</source>
        <translation>删除读者</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1059"/>
        <source>ReaderTable</source>
        <translation>读者列表</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1064"/>
        <source>UserLog</source>
        <translation>用户日志</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1069"/>
        <source>BookLog</source>
        <translation>书籍日志</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1074"/>
        <source>UpdateReader</source>
        <translation>更新读者</translation>
    </message>
    <message>
        <location filename="booksystem.ui" line="1079"/>
        <source>UpdateBook</source>
        <translation>更新书籍</translation>
    </message>
</context>
<context>
    <name>LendManage</name>
    <message>
        <location filename="LendManage.cpp" line="29"/>
        <source>OverDue/Days</source>
        <translation>是否逾期/逾期天数</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="30"/>
        <source>ReaderID</source>
        <translation>读者ID</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="31"/>
        <source>ReaderName</source>
        <translation>读者名字</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="32"/>
        <source>BookID</source>
        <translation>书籍编号</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="33"/>
        <source>BookName</source>
        <translation>书籍名字</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="34"/>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="35"/>
        <source>Type</source>
        <translation>书籍类型</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="36"/>
        <source>Press</source>
        <translation>出版社</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="37"/>
        <source>PublishDate</source>
        <translation>出版日期</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="38"/>
        <source>PageNum</source>
        <translation>页数</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="39"/>
        <source>Price</source>
        <translation>价格</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="40"/>
        <source>LendDays</source>
        <translation>借出天数</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="41"/>
        <source>LendDate</source>
        <translation>借出日期</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="66"/>
        <source>Result</source>
        <translation>结果</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="90"/>
        <location filename="LendManage.cpp" line="143"/>
        <location filename="LendManage.cpp" line="180"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="90"/>
        <location filename="LendManage.cpp" line="143"/>
        <location filename="LendManage.cpp" line="180"/>
        <source>Select a book!</source>
        <translation>请选择一本书！</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="97"/>
        <source>Delete Book</source>
        <translation>删除书籍</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="97"/>
        <source>Delete &lt;&lt;</source>
        <translation>删除《</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="98"/>
        <location filename="LendManage.cpp" line="151"/>
        <source>&gt;&gt;?</source>
        <translation>》？</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="150"/>
        <source>Return Book</source>
        <translation>归还书籍</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="150"/>
        <source>Return &lt;&lt;</source>
        <translation>归还&lt;&lt;</translation>
    </message>
    <message>
        <location filename="LendManage.cpp" line="174"/>
        <source>Renewal</source>
        <translation>续借书籍</translation>
    </message>
</context>
<context>
    <name>LendManageClass</name>
    <message>
        <source>MainWindow</source>
        <translation type="obsolete">借出管理</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="14"/>
        <source>LendManage</source>
        <translatorcomment>借阅管理</translatorcomment>
        <translation></translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="27"/>
        <source>Reader:</source>
        <translation>读者：</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="50"/>
        <source>BookName:</source>
        <translation>书籍名字：</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="73"/>
        <location filename="LendManage.ui" line="154"/>
        <source>OverDue</source>
        <translation>逾期统计</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="86"/>
        <source>Search</source>
        <translation>查找</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="120"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="139"/>
        <source>Return</source>
        <oldsource>Retuen</oldsource>
        <translation>归还书籍</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="144"/>
        <source>Renewal</source>
        <translation>续借书籍</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="149"/>
        <source>LendStatistic</source>
        <translation>借阅统计</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="159"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="164"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="169"/>
        <source>LendList</source>
        <translation>借出列表</translation>
    </message>
    <message>
        <location filename="LendManage.ui" line="174"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
</context>
<context>
    <name>Logon</name>
    <message>
        <location filename="logon.cpp" line="36"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="logon.cpp" line="36"/>
        <source>User name and password can not be null!</source>
        <translation>用户名或密码错误</translation>
    </message>
    <message>
        <location filename="logon.cpp" line="44"/>
        <location filename="logon.cpp" line="48"/>
        <source>Logon</source>
        <translation>登录</translation>
    </message>
</context>
<context>
    <name>LogonClass</name>
    <message>
        <location filename="logon.ui" line="26"/>
        <source>Logon</source>
        <translation>登录</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;宋体&apos;;&quot;&gt;UserID:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">账号：</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Password:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">密码：</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Power:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">权限：</translation>
    </message>
    <message>
        <location filename="logon.ui" line="51"/>
        <source>UserID:</source>
        <translation>账   号：</translation>
    </message>
    <message>
        <location filename="logon.ui" line="61"/>
        <source>PassWord:</source>
        <translation>密   码：</translation>
    </message>
    <message>
        <location filename="logon.ui" line="78"/>
        <source>Power:</source>
        <translation>权   限：</translation>
    </message>
    <message>
        <location filename="logon.ui" line="95"/>
        <source>Administrator</source>
        <translation>管理员</translation>
    </message>
    <message>
        <location filename="logon.ui" line="100"/>
        <source>Operator</source>
        <translation>操作员</translation>
    </message>
    <message>
        <location filename="logon.ui" line="105"/>
        <source>Reader</source>
        <translation>读者</translation>
    </message>
    <message>
        <location filename="logon.ui" line="134"/>
        <source>&amp;Logon</source>
        <translation>登录</translation>
    </message>
    <message>
        <location filename="logon.ui" line="159"/>
        <source>&amp;Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>ReaderInfoClass</name>
    <message>
        <location filename="ReaderInfo.ui" line="14"/>
        <source>ReaderInfo</source>
        <translation>读者信息</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;ReaderID:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">读者ID：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;ReaderName:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">读者名字：</translation>
    </message>
    <message>
        <location filename="ReaderInfo.ui" line="26"/>
        <source>ReaderID:</source>
        <translation>读者编号：</translation>
    </message>
    <message>
        <location filename="ReaderInfo.ui" line="36"/>
        <source>ReaderName:</source>
        <translation>读者姓名：</translation>
    </message>
    <message>
        <location filename="ReaderInfo.ui" line="46"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="ReaderInfo.ui" line="53"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="ReaderInfo.ui" line="60"/>
        <source>LendDays:</source>
        <translation>借出天数：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;LendDays:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">借出天数：</translation>
    </message>
</context>
<context>
    <name>ServerIP</name>
    <message>
        <location filename="serverip.cpp" line="27"/>
        <source>error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="serverip.cpp" line="27"/>
        <source>server ip address error!</source>
        <translation>服务器IP地址不正确！</translation>
    </message>
    <message>
        <location filename="serverip.cpp" line="42"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="serverip.cpp" line="42"/>
        <source>Connect to server failed, Server host can not be found!</source>
        <translation>连接服务器失败，找不到服务器！</translation>
    </message>
</context>
<context>
    <name>ServerIPClass</name>
    <message>
        <location filename="serverip.ui" line="26"/>
        <source>ServerIP</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;宋体&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Server IP:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">IP地址：</translation>
    </message>
    <message>
        <location filename="serverip.ui" line="36"/>
        <source>Server IP:</source>
        <translation>服务器IP：</translation>
    </message>
    <message>
        <location filename="serverip.ui" line="43"/>
        <source>&amp;Connect</source>
        <translation>连接</translation>
    </message>
    <message>
        <location filename="serverip.ui" line="63"/>
        <source>&amp;Exit</source>
        <translation>退出</translation>
    </message>
</context>
<context>
    <name>TableView</name>
    <message>
        <location filename="TableView.cpp" line="12"/>
        <source>Male</source>
        <translation>男</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="13"/>
        <source>Female</source>
        <translation>女</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="15"/>
        <source>Normal</source>
        <translation>正常</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="16"/>
        <source>Non-Use</source>
        <translation>禁用</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="18"/>
        <source>Online</source>
        <translation>在线</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="19"/>
        <source>OffLine</source>
        <translation>离线</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="21"/>
        <source>Administrator</source>
        <translation>管理员</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="22"/>
        <source>Operator</source>
        <translation>操作员</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="24"/>
        <source>[ InLibrary ]</source>
        <translation>在馆</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="25"/>
        <source>[ LendOut ]</source>
        <translation>借出</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="26"/>
        <source>[ Lost ]</source>
        <translation>丢失</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="28"/>
        <source>LogonSystem</source>
        <translation>登录系统</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="29"/>
        <source>AddUser</source>
        <translation>添加用户</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="30"/>
        <source>DeleteUser</source>
        <translation>删除用户</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="31"/>
        <source>UpdateUser</source>
        <translation>更新用户</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="32"/>
        <source>ModifyPassword</source>
        <translation>修改密码</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="33"/>
        <source>LogOut</source>
        <translation>注销</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="34"/>
        <source>DeleteBookLog</source>
        <translation>删除书籍日志</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="35"/>
        <source>AddReader</source>
        <translation>删除读者</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="36"/>
        <source>DeleteReader</source>
        <translation>删除读者</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="37"/>
        <source>UpdateReader</source>
        <translation>更新读者</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="39"/>
        <source>General</source>
        <translation>普通用户</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="40"/>
        <source>VIP</source>
        <translation>VIP</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="42"/>
        <source>AddBook</source>
        <translation>添加书籍</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="43"/>
        <source>DeleteBook</source>
        <translation>删除书籍</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="44"/>
        <source>UpdateBook</source>
        <translation>更新书籍</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="45"/>
        <source>LendOutBook</source>
        <translation>借出书籍</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="46"/>
        <source>ReturnBook</source>
        <translation>归还书籍</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="47"/>
        <source>Renewal</source>
        <translation>续借书籍</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="48"/>
        <source>DeleteLendBook</source>
        <translation>删除借出书籍</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="217"/>
        <source>FAILURE</source>
        <translation>失败</translation>
    </message>
    <message>
        <location filename="TableView.cpp" line="223"/>
        <source>SUEECSS</source>
        <translation>成功</translation>
    </message>
</context>
<context>
    <name>UpdatePwd</name>
    <message>
        <location filename="updatepwd.cpp" line="31"/>
        <location filename="updatepwd.cpp" line="47"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="updatepwd.cpp" line="31"/>
        <source>Input your new password!</source>
        <translation>输入新密码！</translation>
    </message>
    <message>
        <location filename="updatepwd.cpp" line="47"/>
        <source>Password must be the same at two times input!</source>
        <translation>两次输入密码不一致！</translation>
    </message>
    <message>
        <location filename="updatepwd.cpp" line="54"/>
        <source>UpdatePass</source>
        <translation>修改密码</translation>
    </message>
    <message>
        <location filename="updatepwd.cpp" line="54"/>
        <source>Password is wrong!</source>
        <translation>密码错误</translation>
    </message>
    <message>
        <location filename="updatepwd.cpp" line="77"/>
        <location filename="updatepwd.cpp" line="81"/>
        <source>Logon</source>
        <translation>登录</translation>
    </message>
</context>
<context>
    <name>UpdatePwdClass</name>
    <message>
        <location filename="updatepwd.ui" line="26"/>
        <source>UpdatePwd</source>
        <translation>修改密码</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;宋体&apos;;&quot;&gt;OldPass:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">旧密码：</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;宋体&apos;;&quot;&gt;NewPass:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">新密码：</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;宋体&apos;;&quot;&gt;ConfirmPass:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">再次输入：</translation>
    </message>
    <message>
        <location filename="updatepwd.ui" line="36"/>
        <source>OldPass:</source>
        <translation>旧 密 码：</translation>
    </message>
    <message>
        <location filename="updatepwd.ui" line="50"/>
        <source>NewPass:</source>
        <translation>新 密 码：</translation>
    </message>
    <message>
        <location filename="updatepwd.ui" line="64"/>
        <source>ConfirmPass:</source>
        <translation>确认密码：</translation>
    </message>
    <message>
        <location filename="updatepwd.ui" line="103"/>
        <source>&amp;Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="updatepwd.ui" line="122"/>
        <source>&amp;OK</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>UserDialog</name>
    <message>
        <location filename="UserDialog.cpp" line="26"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="UserDialog.cpp" line="26"/>
        <source>Input information incompletely!</source>
        <translation>请输入完整的信息！</translation>
    </message>
</context>
<context>
    <name>UserDialogClass</name>
    <message>
        <location filename="UserDialog.ui" line="26"/>
        <source>UserDialog</source>
        <translation>用户</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Password:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">密码：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;ID:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">用户账号：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;IDCard:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">证件号码：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Name:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">真实姓名：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Sex:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">性别：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="90"/>
        <source>Male</source>
        <translation>男</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="95"/>
        <source>Female</source>
        <translation>女</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;E-mail:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">E-Mail：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="113"/>
        <source>yyyy-MM-dd</source>
        <translation></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Birthday:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">出生年月：</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Phone:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">电话：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="134"/>
        <source>Normal</source>
        <translation>正常</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="139"/>
        <source>Non-Use</source>
        <translation>禁用</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Status:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">状态：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="155"/>
        <source>Administrator</source>
        <translation>管理员</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="160"/>
        <source>Operator</source>
        <translation>操作员</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;right&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Power:&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">权限：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="38"/>
        <source>Password:</source>
        <translation>*密   码：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="45"/>
        <source>ID:</source>
        <translation>*账   号：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="52"/>
        <source>IDCard:</source>
        <translation>证件号码：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="75"/>
        <source>Name:</source>
        <translation>真实姓名：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="82"/>
        <source>Sex:</source>
        <translation>性    别：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="103"/>
        <source>E-Mail</source>
        <translation>E-Mail  ：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="123"/>
        <source>Birthday:</source>
        <translation>出生年月：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="147"/>
        <source>Status:</source>
        <translation>用户状态：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="168"/>
        <source>Power:</source>
        <translation>用户权限：</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="175"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="182"/>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="189"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="UserDialog.ui" line="196"/>
        <source>Phone:</source>
        <translation>电话号码：</translation>
    </message>
</context>
<context>
    <name>UserLogManage</name>
    <message>
        <location filename="UserLogManage.cpp" line="23"/>
        <location filename="UserLogManage.cpp" line="60"/>
        <location filename="UserLogManage.cpp" line="65"/>
        <source>Result</source>
        <translation>结果</translation>
    </message>
    <message>
        <location filename="UserLogManage.cpp" line="24"/>
        <source>Operator</source>
        <translation>操作员</translation>
    </message>
    <message>
        <location filename="UserLogManage.cpp" line="25"/>
        <source>Operation</source>
        <translation>操作</translation>
    </message>
    <message>
        <location filename="UserLogManage.cpp" line="26"/>
        <source>IP</source>
        <translation>操作员IP</translation>
    </message>
    <message>
        <location filename="UserLogManage.cpp" line="27"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="UserLogManage.cpp" line="28"/>
        <source>DateTime</source>
        <translation>操作日期</translation>
    </message>
    <message>
        <location filename="UserLogManage.cpp" line="42"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="UserLogManage.cpp" line="43"/>
        <source>Ensure delete user log?</source>
        <translation>确定删除书籍日志</translation>
    </message>
    <message>
        <location filename="UserLogManage.cpp" line="60"/>
        <source>Delete book log successfully!</source>
        <translation>删除书籍日志成功</translation>
    </message>
    <message>
        <location filename="UserLogManage.cpp" line="65"/>
        <source>Delete book log failed!
</source>
        <translation>输出书籍日志失败</translation>
    </message>
</context>
<context>
    <name>UserLogManageClass</name>
    <message>
        <source>MainWindow</source>
        <translation type="obsolete">书籍日志管理</translation>
    </message>
    <message>
        <location filename="UserLogManage.ui" line="14"/>
        <source>UserLogManage</source>
        <translation>用户日志管理</translation>
    </message>
    <message>
        <location filename="UserLogManage.ui" line="26"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="UserLogManage.ui" line="41"/>
        <source>Delete</source>
        <translation>删除日志</translation>
    </message>
    <message>
        <location filename="UserLogManage.ui" line="46"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="UserLogManage.ui" line="51"/>
        <source>Search</source>
        <translation>查找</translation>
    </message>
    <message>
        <location filename="UserLogManage.ui" line="56"/>
        <source>exit</source>
        <translation>退出</translation>
    </message>
</context>
<context>
    <name>UserManage</name>
    <message>
        <location filename="UserManage.cpp" line="41"/>
        <source>ID</source>
        <translation>账号</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="42"/>
        <source>Name</source>
        <translation>姓名</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="40"/>
        <source>Sex</source>
        <translation>性别</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="43"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="44"/>
        <source>Power</source>
        <translation>权限</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="45"/>
        <source>Birthday</source>
        <translation>出生年月</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="46"/>
        <source>IDCard</source>
        <translation>证件号码</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="47"/>
        <source>Phone</source>
        <translation>电话</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="48"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="49"/>
        <source>LoginTime</source>
        <translation>注册时间</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="50"/>
        <source>E-mail</source>
        <translation></translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="51"/>
        <source>IsOnline</source>
        <translation>在线状态</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="52"/>
        <source>LastTime</source>
        <translation>最后登录时间</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="57"/>
        <source>AddUser</source>
        <translation>添加用户</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="70"/>
        <location filename="UserManage.cpp" line="83"/>
        <location filename="UserManage.cpp" line="89"/>
        <location filename="UserManage.cpp" line="101"/>
        <source>Result</source>
        <translation>结果</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="71"/>
        <source>Continue?</source>
        <translation>继续？</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="154"/>
        <location filename="UserManage.cpp" line="175"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="154"/>
        <location filename="UserManage.cpp" line="175"/>
        <source>Select a user!</source>
        <translation>请选择一个用户！</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="161"/>
        <source>Delete User</source>
        <translation>删除用户</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="161"/>
        <source>Delete &lt;&lt;</source>
        <translation>删除&lt;&lt;</translation>
    </message>
    <message>
        <location filename="UserManage.cpp" line="179"/>
        <source>UpdateUser</source>
        <translation>更新用户</translation>
    </message>
</context>
<context>
    <name>UserManageClass</name>
    <message>
        <source>MainWindow</source>
        <translation type="obsolete">用户管理</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="14"/>
        <source>UserManage</source>
        <translation>用户管理</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="35"/>
        <source>UserID:</source>
        <translation>用户ID：</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="70"/>
        <source>UserName:</source>
        <translation>用户名：</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="105"/>
        <source>Search</source>
        <translation>查找</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="139"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="155"/>
        <source>AddUser</source>
        <translation>添加用户</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="160"/>
        <source>DeleteUser</source>
        <translation>删除用户</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="165"/>
        <source>Update</source>
        <translation>更新用户</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="170"/>
        <source>QueryUser</source>
        <translation>查询用户</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="175"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="UserManage.ui" line="180"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
</context>
</TS>
